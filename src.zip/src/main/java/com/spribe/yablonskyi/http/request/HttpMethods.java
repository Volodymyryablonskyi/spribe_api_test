package com.spribe.yablonskyi.http.request;

public enum HttpMethods {
    GET, POST, PUT, DELETE, PATCH;
}
