package com.spribe.yablonskyi.pojo;

public class GetPlayerRequestPojo {

    private Long playerId;


    public Long getPlayerId() {
        return playerId;
    }

    public GetPlayerRequestPojo setPlayerId(Long playerId) {
        this.playerId = playerId;
        return this;
    }
}
