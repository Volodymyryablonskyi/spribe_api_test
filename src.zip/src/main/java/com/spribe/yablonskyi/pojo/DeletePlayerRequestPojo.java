package com.spribe.yablonskyi.pojo;

public class DeletePlayerRequestPojo {

    private long playerId;

    public long getPlayerId() {
        return playerId;
    }

    public DeletePlayerRequestPojo setPlayerId(long playerId) {
        this.playerId = playerId;
        return this;
    }

}
