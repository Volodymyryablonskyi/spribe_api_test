package com.spribe.yablonskyi.data;

public class GlobalTestData {

    public static final String OPERATION = "Operation";
    public static final String OP_CREATE = "CREATE";
    public static final String EDITOR = "Editor";
    public static final String TARGET_ROLE = "TargetRole";
    public static final String TARGET = "Target";
    public static final String AGE = "Age";
    public static final String GENDER = "Gender";
    public static final String PASSWORD = "Password";
    public static final String PASSWORD_LENGTH = "PasswordLength";
    public static final String ACTUAL = "Actual";

}
