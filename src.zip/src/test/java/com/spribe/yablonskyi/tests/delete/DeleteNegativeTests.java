package com.spribe.yablonskyi.tests.delete;

import com.spribe.yablonskyi.base.BasePlayerTest;

public class DeleteNegativeTests extends BasePlayerTest {
}
